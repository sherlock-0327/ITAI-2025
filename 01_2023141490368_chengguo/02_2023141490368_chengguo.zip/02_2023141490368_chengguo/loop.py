import random
import matplotlib.pyplot as plt
import numpy as np

# 设置matplotlib支持中文显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

def simulate_loop_strategy(N=100, K=50, T=10000):
    """
    使用循环策略模拟囚犯抽签问题
    
    参数:
    N: 囚犯数量
    K: 每个囚犯最多尝试次数
    T: 模拟轮次
    
    返回:
    success_rate: 总体成功率
    success_days: 成功天数的分布
    """
    success_count = 0
    success_days = []
    
    for t in range(T):
        # 初始化盒子，每个盒子随机放置一个囚犯编号
        boxes = list(range(1, N+1))
        random.shuffle(boxes)
        
        all_found = True
        
        # 每个囚犯尝试找到自己的编号
        for prisoner in range(1, N+1):
            current_box = prisoner - 1  # 从自己编号的盒子开始
            found = False
            
            for _ in range(K):
                if boxes[current_box] == prisoner:
                    found = True
                    break
                # 移动到下一个盒子（根据当前盒子中的编号）
                current_box = boxes[current_box] - 1
            
            if not found:
                all_found = False
                break
        
        if all_found:
            success_count += 1
            success_days.append(t+1)
    
    success_rate = success_count / T * 100
    return success_rate, success_days

def plot_results(success_rate, success_days, strategy_name):
    """绘制结果图表"""
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.hist(success_days, bins=50)
    plt.title(f'{strategy_name} - 成功天数分布')
    plt.xlabel('模拟轮次')
    plt.ylabel('成功次数')
    
    plt.subplot(1, 2, 2)
    labels = ['成功', '失败']
    sizes = [success_rate, 100 - success_rate]
    plt.pie(sizes, labels=labels, autopct='%1.2f%%', startangle=90)
    plt.title(f'{strategy_name} - 总体成功率: {success_rate:.2f}%')
    
    plt.tight_layout()
    plt.savefig(f'{strategy_name.replace(" ", "_")}_results.png')
    plt.show()

# 运行模拟
success_rate, success_days = simulate_loop_strategy()
plot_results(success_rate, success_days, "循环策略")

print(f"循环策略 - 总体成功率: {success_rate:.2f}%")
