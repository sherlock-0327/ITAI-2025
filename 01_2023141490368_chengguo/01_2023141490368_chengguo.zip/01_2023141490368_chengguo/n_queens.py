import time

def is_safe(board, row, col, n):
    """检查在指定位置放置皇后是否安全"""
    # 检查列
    for i in range(row):
        if board[i][col] == 1:
            return False
    
    # 检查左上对角线
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j] == 1:
            return False
    
    # 检查右上对角线
    for i, j in zip(range(row, -1, -1), range(col, n)):
        if board[i][j] == 1:
            return False
    
    return True

def solve_n_queens(n, find_all=True):
    """使用回溯法解决N皇后问题
    find_all: 是否查找所有解，False表示找到一个解就返回
    """
    board = [[0 for _ in range(n)] for _ in range(n)]
    solutions = []
    
    def backtrack(row):
        if row == n:
            # 找到一个解，将其添加到解决方案列表中
            solution = []
            for i in range(n):
                row_str = ""
                for j in range(n):
                    row_str += "Q" if board[i][j] == 1 else "."
                solution.append(row_str)
            solutions.append(solution)
            return True  # 返回True表示找到了解
        
        for col in range(n):
            if is_safe(board, row, col, n):
                board[row][col] = 1  # 放置皇后
                if backtrack(row + 1):  # 如果找到解
                    if not find_all:  # 如果只需要一个解
                        return True  # 立即返回
                board[row][col] = 0  # 回溯，移除皇后
        
        return False  # 返回False表示当前分支无解
    
    backtrack(0)
    return solutions

def print_solutions(solutions):
    """打印所有解决方案"""
    for i, solution in enumerate(solutions):
        print(f"解决方案 {i+1}:")
        for row in solution:
            print(row)
        print()

def main():
    try:
        n = int(input("请输入皇后的数量 (N): "))
        if n < 1:
            print("N必须大于等于1")
            return
        
        output_option = input("是否输出全部解？(y/n): ").lower()
        find_all = output_option == 'y'
        
        start_time = time.time()  # 记录开始时间
        
        solutions = solve_n_queens(n, find_all)
        
        end_time = time.time()    # 记录结束时间
        elapsed_time = end_time - start_time
        
        print(f"\n找到 {len(solutions)} 个解决方案")
        
        if find_all:
            if solutions:
                print_solutions(solutions)  # 打印所有解决方案
            else:
                print("没有找到解决方案")
        else:
            if solutions:
                print_solutions(solutions[:1])  # 只打印第一个解决方案
            else:
                print("没有找到解决方案")
        
        print(f"\n程序运行时间: {elapsed_time:.6f} 秒")
        
    except ValueError:
        print("请输入有效的整数")

if __name__ == "__main__":
    main()
